//
//  ContentView.swift
//  SSeu
//
//  Created by Turma01-23 on 27/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MyTabView()
        
    }
}

#Preview {
    ContentView()
}
