//
//  Teste.swift
//  SSeu
//
//  Created by Turma01-23 on 12/03/25.
//

import SwiftUI

struct Teste: View {
    
    
    @EnvironmentObject var vm: ProdutosViewModel
    
    var body: some View {
        VStack{
        ForEach(vm.carrinho, id: \.self){ p in
            Text(p.produto.nome)
        }.onDelete(perform: vm.removeFromCart)
            
    }
}

#Preview {
    Teste()
}
