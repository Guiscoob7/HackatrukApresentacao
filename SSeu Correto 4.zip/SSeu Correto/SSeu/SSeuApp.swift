//
//  SSeuApp.swift
//  SSeu
//
//  Created by Turma01-23 on 25/02/25.
//

import SwiftUI

@main
struct SSeuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
