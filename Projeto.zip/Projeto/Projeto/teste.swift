//
//  teste.swift
//  Projeto
//
//  Created by Turma01-24 on 28/02/25.
//

import SwiftUI

struct teste: View {
    var body: some View {
        NavigationStack{
            NavigationLink(destination: CarrinhoView()){
                Text("Hello, World!")

            }
        }
    }
}

#Preview {
    teste()
}
