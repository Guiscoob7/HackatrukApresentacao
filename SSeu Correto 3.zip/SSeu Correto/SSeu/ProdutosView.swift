import SwiftUI


struct Produto: Identifiable, Decodable, Hashable {
    let id: Int
    let nome: String
    let valor: Double
    let peso: Double
    let tipo_peso: String
    let imagem: String
    let categoria: String
}

struct item : Hashable{

    var qtde: Int
    var produto : Produto
    
}

class ProdutosViewModel: ObservableObject {
    @Published var produtos: [Produto] = []
    @Published var fav : [Produto] = []
    
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil

    
    @Published var carrinho : [item] = []
    
    func contador () -> Int{
        var total : Int = 0
        for index in carrinho {
            
            total += index.qtde
            
        }
        
        return total

        
    }
    
    func fetchProdutos() {
        isLoading = true
        errorMessage = nil
        
        guard let url = URL(string: "http://127.0.0.1:1880/projetoGet") else {
            self.errorMessage = "URL inválida"
            self.isLoading = false
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false
                
                if let error = error {
                    self.errorMessage = "Erro ao buscar dados: \(error.localizedDescription)"
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    self.errorMessage = "Resposta inválida do servidor"
                    return
                }
                
                guard let data = data else {
                    self.errorMessage = "Dados não encontrados"
                    return
                }
                
                do {
                    let decodedData = try JSONDecoder().decode([Produto].self, from: data)
                    self.produtos = decodedData
                } catch {
                    self.errorMessage = "Erro ao decodificar dados: \(error.localizedDescription)"
                }
            }
        }.resume()
    }
}
