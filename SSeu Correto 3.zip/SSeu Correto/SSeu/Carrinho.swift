//
//  Carrinho.swift
//  SSeu
//
//  Created by Turma01-23 on 10/03/25.
//

import SwiftUI

struct Carrinho: View {

    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Carrinho()
}
