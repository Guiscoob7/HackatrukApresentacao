//
//  estrutura.swift
//  TelaDescricaoPF
//
//  Created by Turma01-14 on 25/02/25.
//

import Foundation

struct Dado: Hashable{
    
    let imagem: String
    let nome: String
    let descricao: String
    let preco: Double
    
}


struct item : Hashable{
    
    var qtde: Int
    var produto : Dado
    
}



var dados = [ Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal com gás", preco: 35),
              Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 12),
              Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 1.34),
              Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 12.3),
              Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 12.4), Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 2.34), Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 2.4), Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 2.3), Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 1.4), Dado(imagem: "https://abir.org.br/abir2022/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-30-at-15.26.58.jpeg", nome: "Água sem gás", descricao: "Água mineral Crystal sem gás", preco: 1.4)]


