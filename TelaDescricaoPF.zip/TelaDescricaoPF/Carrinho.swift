//
//  Carrinho.swift
//  TelaDescricaoPF
//
//  Created by Turma01-14 on 25/02/25.
//

import SwiftUI

struct Carrinho: View {
    
    @State var number1: Int = 0
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Carrinho()
}
