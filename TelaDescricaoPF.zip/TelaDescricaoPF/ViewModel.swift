//
//  ModelView.swift
//  TelaDescricaoPF
//
//  Created by Turma01-14 on 27/02/25.
//

import Foundation


class ProductView : ObservableObject{
    
    @Published var fav : [Dado] = []
    
    @Published var carrinho : [item] = []
    

    
    func contador () -> Int{
        var total : Int = 0
        for index in carrinho {
            
            total += index.qtde
            
        }
        
        return total

        
    }
    
    
    
}


