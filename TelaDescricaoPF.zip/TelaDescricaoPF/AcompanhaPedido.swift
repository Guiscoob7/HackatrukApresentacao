//
//  AcompanhaPedido.swift
//  TelaDescricaoPF
//
//  Created by Turma01-14 on 25/02/25.
//

import SwiftUI

struct AcompanhaPedido: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AcompanhaPedido()
}
