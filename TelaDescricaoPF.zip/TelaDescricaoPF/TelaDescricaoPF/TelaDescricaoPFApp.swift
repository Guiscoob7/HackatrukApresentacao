//
//  TelaDescricaoPFApp.swift
//  TelaDescricaoPF
//
//  Created by Turma01-14 on 25/02/25.
//

import SwiftUI

@main
struct TelaDescricaoPFApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
