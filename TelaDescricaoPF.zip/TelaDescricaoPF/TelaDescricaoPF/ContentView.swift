//
//  ContentView.swift
//  TelaDescricaoPF
//
//  Created by Turma01-14 on 25/02/25.
//

import SwiftUI



struct ContentView: View {
    
    @State var number2: Int = 0
    
    @StateObject var vm = ProductView()
    
    var body: some View {
        
        
        
        TabView{
            
            
            Busca(vm: vm)
                .tabItem{
                    Label ("Busca",systemImage: "magnifyingglass")
                }
            
            AcompanhaPedido()
            
                .tabItem{
                    Label ("Acompanhar Pedido",systemImage: "mappin.and.ellipse.circle.fill")
                }
            
            
            
            Carrinho()
                .badge("+\(vm.contador())")
                .tabItem{
                    Label ("Carrinho",systemImage: "cart.fill")
                }
        }
    }
}

#Preview {
    ContentView()
}
