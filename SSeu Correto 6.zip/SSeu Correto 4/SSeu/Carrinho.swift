//
//  carrinho.swift
//  ProjetoFinalCarrinho
//
//  Created by Turma01-15 on 25/02/25.
//

import SwiftUI


struct Carrinho: View {
    
    @StateObject var vm : ProdutosViewModel

    
    @State var bairro : String = ""
    @State var rua : String = ""
    @State var num : Int = 0
    @State var cpf : Int = 0
    
    var body: some View {
        NavigationStack{
            ZStack{
                VStack{
                    HStack(alignment: .bottom){
                        Spacer()
                        Text ("S")
                            .font(.system(size: 40, weight: .bold, design: .serif))
                            .foregroundStyle(.white)
                        Text ("Seu")
                            .font(.system(size: 40, weight: .bold, design: .serif))
                            .foregroundStyle(.yellow)
                        Text ("Carrinho...")
                            .font(.system(size: 40, weight: .bold, design: .serif))
                            .foregroundStyle(.blue)
                        Spacer()
                    }.frame(width: .infinity, height: .infinity).background(.vermelhoVivo)
                    
                    ScrollView{
                        
                        ForEach(vm.carrinho, id:\.self){ e in
                            HStack{
                                ZStack{
                                    AsyncImage(url: URL(string: e.produto.imagem), content: { img in
                                        img.resizable()
                                            .scaledToFit()
                                            .frame(width: 60)
                                        
                                    }, placeholder: {
                                        ProgressView()
                                    })
                                }
                                
                                
                                VStack(alignment: .leading){
                                    Text(e.produto.nome)
                                        .font(.system(size: 18, weight: .bold, design: .serif))
                                        .foregroundStyle(.black)
                                    
                                    Text ("R$ \(e.produto.valor, specifier: "%.2f")")
                                        .font(.system(size: 18, weight: .bold, design: .serif))
                                        .foregroundStyle(.black)
                                    
                                }
                                
                                Spacer()
                                
                                Image( systemName: "trash.fill")
                                    .foregroundStyle(.black)
                                    .padding()
                            }.padding()
                            Divider().background()
                            
                        }
                        Spacer()
                        
                        
                        NavigationLink(destination: EnderecoView()){
                            Text ("Ir para área de cadastro")
                                .font(.system(size: 20, weight: .bold, design: .serif))
                                .frame (width: 330, height: 60)
                                .background(.vermelhoVivo)
                                .foregroundColor(.white)
                                .cornerRadius(20)
                                .padding(.top)
                        }
                    }
                }
            }.edgesIgnoringSafeArea(.top)
        }
    }
}

struct CarrinhoExemplo: PreviewProvider{
    static var previews: some View {
        @StateObject var vm = ProdutosViewModel()
        
        Carrinho(vm: vm)
    }
}
