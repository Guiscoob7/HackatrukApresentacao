//
//  CoreLocationDelegate.swift
//  GPS
//
//  Created by Turma01-23 on 11/03/25.
//

import Foundation
import CoreLocation

class CoreLocationDelegate: NSObject, CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations)
    }
    
}
