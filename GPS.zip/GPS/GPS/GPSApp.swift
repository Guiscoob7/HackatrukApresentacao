//
//  GPSApp.swift
//  GPS
//
//  Created by Turma01-23 on 10/03/25.
//

import SwiftUI
import CoreLocation

@main
struct GPSApp: App {
    
    let locationManager = CLLocationManager()
    let coreLocationDelegate = CoreLocationDelegate()
    
    init() {
        
        locationManager.delegate = coreLocationDelegate
        locationManager.allowsBackgroundLocationUpdates = true
        locationManager.distanceFilter = 30
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
