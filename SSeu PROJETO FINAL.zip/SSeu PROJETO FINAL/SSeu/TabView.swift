//
//  TabView.swift
//  SSeu
//
//  Created by Turma01-23 on 27/02/25.
//

import SwiftUI

struct MyTabView: View {
    @State private var selectedTab = "Busca"
    
    @StateObject var vm = ProdutosViewModel()
    
    var body: some View {
        TabView(selection: $selectedTab) {
            SearchView(vm: vm)
                .tabItem {
                    VStack {
                        Image(systemName: "magnifyingglass")
                        Text("Busca")
                    }
                }
                .tag("Busca")
            
            DeliverView(goBack: {
            })
            .tabItem {
                VStack {
                    Image(systemName: "safari")
                    Text("Entrega")
                }
            }
            .tag("Entrega")
            
            Carrinho(vm: vm)
                .badge("+\(vm.contador())")
                .tabItem{
                    Label ("Carrinho",systemImage: "cart.fill")
                }
        }
        .accentColor(.red)
    }
}



#Preview {
    MyTabView()
}
