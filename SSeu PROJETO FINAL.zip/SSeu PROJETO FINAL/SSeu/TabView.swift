//
//  TabView.swift
//  SSeu
//
//  Created by Turma01-23 on 27/02/25.
//

import SwiftUI

struct MyTabView: View {
    @State private var selectedTab = "Busca"
    
    @EnvironmentObject var vm: ProdutosViewModel
    
    var body: some View {
        TabView(selection: $selectedTab) {
            SearchView()
                .tabItem {
                    VStack {
                        Image(systemName: "magnifyingglass")
                        Text("Busca")
                    }
                }
                .tag("Busca")
            
            DeliverView()
                .tabItem {
                    VStack {
                        Image(systemName: "safari")
                        Text("Entrega")
                    }
                }
                .tag("Entrega")
            
            Carrinho()
                .badge("+\(vm.contador())")
                .tabItem{
                    Label ("Carrinho",systemImage: "cart.fill")
                }
        }
        .accentColor(.red)
    }
}

#Preview {
    MyTabView()
}
