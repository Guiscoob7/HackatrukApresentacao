//
//  Busca.swift
//  TelaDescricaoPF
//
//  Created by Turma01-14 on 25/02/25.
//

import SwiftUI

struct Busca: View {
    
    @State var cor: Bool = false
    @State var color: Color = .black
    @State var number: Int = 0
    
    @State var categoriaSelecionada: String
    @EnvironmentObject var vm: ProdutosViewModel
    
    var body: some View {
        
            VStack{

                
                ScrollView{
                    
                    
                    
                    HStack{
                        
                        Spacer()
                        Text("\(categoriaSelecionada)").bold().font(.system(size: 45)).foregroundStyle(.white)
                        Spacer()
                    }.background(.red).frame(width: .infinity,height: .infinity).cornerRadius(20).padding(.horizontal)
                    
                    
                    
                    ForEach (vm.produtos.filter({$0.categoria.lowercased().contains(categoriaSelecionada.lowercased())})){ m in
                        
                        
                        HStack{
                            
                            AsyncImage(url: URL(string: m.imagem)) { imag in
                                imag.resizable()
                                    .scaledToFit()
                                    .clipShape(Circle())
                            } placeholder: {
                                ProgressView()
                                
                            }.frame(width: 100, height: 100)
                            
                            VStack(alignment:.leading){
                                
                                Text(m.nome).bold()
                                Text ("R$ \(m.valor, specifier: "%.2f")").bold()
                                
                            }
                            
                            
                            Spacer()
                            if  vm.fav.contains(where: { $0 == m}) {
                                Image(systemName: "heart.circle.fill").font(.system(size: 25))
                                    .onTapGesture {
                                        
                                        vm.fav.removeLast()
                                        
                                    }.foregroundStyle(.red)
                            }else{
                                
                                Image(systemName: "heart.circle.fill").font(.system(size: 25))
                                    .onTapGesture {
                                        
                                        vm.fav.append(m)
                                        
                                    }.foregroundStyle(.black)
                                
                            }
                            
                            
                            Image(systemName: "plus.circle.fill").onTapGesture {
                                vm.addItem(p: m)
                            }.font(.system(size: 25))
                            
                            Image(systemName: "minus.circle.fill").font(.system(size: 25)).onTapGesture {
                                
                                let ProdutoJaExiste =  vm.carrinho.filter({ $0.produto == m })
                                
                                print(ProdutoJaExiste.count)
                                if(ProdutoJaExiste.count > 0){
                                    if  ProdutoJaExiste.first!.qtde > 0{
                                        
                                        let produtoComprado = item(qtde: ProdutoJaExiste.first!.qtde-1, produto: m)
                                        
                                        
                                        vm.carrinho.removeAll(where: { $0 == ProdutoJaExiste.first! })
                                        
                                        vm.carrinho.append(produtoComprado)
                                        
                                        
                                    }
                                }
//                                print ("\(vm.carrinho)\n")
//                                print(vm.contador())
                                
                                
                            }
                            
                            
                            
                            
                            
                            
                        }.padding()
                        
                        Divider().background(.gray)
                        
                    }
                    
                }
                
            }
            
        }
        
    }


struct MyExamplePreviews: PreviewProvider{
    static var previews: some View {
        @StateObject var vm = ProdutosViewModel()
        @State var categoriaSelecionada: String = ""
        
        Busca(categoriaSelecionada: "")
    }
}
