import SwiftUI


struct Produto: Identifiable, Decodable, Hashable {
    let id: Int
    let nome: String
    let valor: Double
    let peso: Double
    let tipo_peso: String
    let imagem: String
    let categoria: String
}

struct item : Hashable{

    var qtde: Int
    var produto : Produto
    
}

class ProdutosViewModel: ObservableObject {
    @Published var produtos: [Produto] = []
    @Published var fav : [Produto] = []
    
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil
    
    
    @Published var carrinho : [item] = []
    
    func contador () -> Int{
        var total : Int = 0
        for index in carrinho {
            
            total += index.qtde
            
        }
        
        return total
        
        
    }
    
    func removeFromCart(p : item) {
        carrinho.removeAll(where: { $0.produto == p.produto})
    }
    
//    
//    (item: item) {
//        carrinho.removeAll { $0.produto == item.produto }
//    }
//    
    
    func addItem(p: Produto) {
        let ProdutoJaExiste =  self.carrinho.filter({ $0.produto == p })
        
        if  ProdutoJaExiste.count > 0{
            
            let produtoComprado = item(qtde: ProdutoJaExiste.first!.qtde+1, produto: p)
            
            
            self.carrinho.removeAll(where: { $0 == ProdutoJaExiste.first! })
            
            self.carrinho.append(produtoComprado)
            
            
        }else{
            self.carrinho.append(item(qtde: 1, produto: p))
            
        }
    }
    
    
    func subTotal () -> Double{
        var subtotal : Double = 0
        for index in carrinho {
            
            subtotal += Double(index.qtde) * index.produto.valor
        }
        return subtotal
    }
    
    func fetchProdutos() {
        isLoading = true
        errorMessage = nil
        
        guard let url = URL(string: "http://192.168.128.110:1880/projetoGet") else {
            self.errorMessage = "URL inválida"
            self.isLoading = false
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false
                
                if let error = error {
                    self.errorMessage = "Erro ao buscar dados: \(error.localizedDescription)"
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    self.errorMessage = "Resposta inválida do servidor"
                    return
                }
                
                guard let data = data else {
                    self.errorMessage = "Dados não encontrados"
                    return
                }
                
                do {
                    let decodedData = try JSONDecoder().decode([Produto].self, from: data)
                    self.produtos = decodedData
                } catch {
                    self.errorMessage = "Erro ao decodificar dados: \(error.localizedDescription)"
                }
            }
        }.resume()
    }
}
