//
//  SSeuApp.swift
//  SSeu
//
//  Created by Turma01-23 on 25/02/25.
//

import SwiftUI

@main
struct SSeuApp: App {
    
    @StateObject private var vm = ProdutosViewModel()
    
    var body: some Scene {
        
        
        WindowGroup {
            ContentView()
                .environmentObject(vm)
        }
    }
}
